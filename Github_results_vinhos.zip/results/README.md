# Results – Classificação da Qualidade de Vinhos

Esta pasta reúne gráficos e métricas exportados das saídas do notebook original do Google Colab.

## Gráficos

- `matrizes_confusao_modelos.png`: matrizes de confusão da Regressão Logística e Random Forest.
- `curva_roc_modelos.png`: comparação das curvas ROC dos dois modelos.
- `f1_por_threshold_random_forest.png`: F1-score por ponto de corte, calculado por validação cruzada no conjunto de treino.
- `matriz_confusao_random_forest_threshold_025.png`: matriz de confusão da Random Forest com threshold 0,25.
- `importancia_variaveis_random_forest.png`: importância das variáveis na Random Forest.
- `coeficientes_regressao_logistica.png`: coeficientes estimados pela Regressão Logística.

## Métricas

- `metricas_teste_modelos.csv`: métricas no conjunto de teste para Regressão Logística e Random Forest com threshold padrão 0,50.
- `metricas_validacao_cruzada.csv`: média e desvio-padrão das métricas na validação cruzada estratificada com 5 folds.
- `comparacao_threshold_random_forest.csv`: comparação da Random Forest com threshold 0,50 e 0,25.

## Observação metodológica

Os arquivos reproduzem os resultados registrados nas saídas do notebook. O threshold 0,25 foi selecionado usando previsões out-of-fold no conjunto de treino e depois avaliado no conjunto de teste. As métricas de validação cruzada e as métricas do teste representam avaliações distintas e não devem ser misturadas.
